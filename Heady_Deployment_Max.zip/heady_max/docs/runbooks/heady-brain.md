# Runbook: heady-brain
## Symptoms
High latency (>1.618s).
## Diagnosis
Check pgvector connection pool.
## Remediation
Restart service with min-instances=2.
