const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('model-gateway');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'model-gateway', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'model-gateway', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3314;
app.listen(port, () => {
    logger.info(`Service ${model-gateway} listening on port ${port}`);
});
