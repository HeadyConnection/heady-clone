const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-pilot-onboarding');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-pilot-onboarding', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'heady-pilot-onboarding', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3341;
app.listen(port, () => {
    logger.info(`Service ${heady-pilot-onboarding} listening on port ${port}`);
});
