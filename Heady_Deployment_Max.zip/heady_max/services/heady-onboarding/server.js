const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-onboarding');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-onboarding', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'heady-onboarding', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3340;
app.listen(port, () => {
    logger.info(`Service ${heady-onboarding} listening on port ${port}`);
});
