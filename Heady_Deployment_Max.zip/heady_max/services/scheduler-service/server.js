const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('scheduler-service');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'scheduler-service', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'scheduler-service', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3365;
app.listen(port, () => {
    logger.info(`Service ${scheduler-service} listening on port ${port}`);
});
