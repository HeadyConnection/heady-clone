const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('silicon-bridge');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'silicon-bridge', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'silicon-bridge', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3353;
app.listen(port, () => {
    logger.info(`Service ${silicon-bridge} listening on port ${port}`);
});
