const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('hcfullpipeline-executor');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'hcfullpipeline-executor', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'hcfullpipeline-executor', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3326;
app.listen(port, () => {
    logger.info(`Service ${hcfullpipeline-executor} listening on port ${port}`);
});
