const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('auto-success-engine');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'auto-success-engine', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'auto-success-engine', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3325;
app.listen(port, () => {
    logger.info(`Service ${auto-success-engine} listening on port ${port}`);
});
