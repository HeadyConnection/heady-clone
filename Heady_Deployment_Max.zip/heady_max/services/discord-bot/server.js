const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('discord-bot');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'discord-bot', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'discord-bot', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3354;
app.listen(port, () => {
    logger.info(`Service ${discord-bot} listening on port ${port}`);
});
