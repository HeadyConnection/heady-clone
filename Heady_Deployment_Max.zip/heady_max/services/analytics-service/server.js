const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('analytics-service');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'analytics-service', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'analytics-service', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3362;
app.listen(port, () => {
    logger.info(`Service ${analytics-service} listening on port ${port}`);
});
