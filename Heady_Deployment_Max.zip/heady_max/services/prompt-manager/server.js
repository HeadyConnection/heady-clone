const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('prompt-manager');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'prompt-manager', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'prompt-manager', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3328;
app.listen(port, () => {
    logger.info(`Service ${prompt-manager} listening on port ${port}`);
});
