const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('google-mcp');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'google-mcp', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'google-mcp', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3347;
app.listen(port, () => {
    logger.info(`Service ${google-mcp} listening on port ${port}`);
});
