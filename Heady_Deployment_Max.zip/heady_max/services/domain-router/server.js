const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('domain-router');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'domain-router', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'domain-router', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3345;
app.listen(port, () => {
    logger.info(`Service ${domain-router} listening on port ${port}`);
});
