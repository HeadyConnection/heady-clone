const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('colab-gateway');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'colab-gateway', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'colab-gateway', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3352;
app.listen(port, () => {
    logger.info(`Service ${colab-gateway} listening on port ${port}`);
});
