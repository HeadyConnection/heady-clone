const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-governance');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-governance', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'heady-governance', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3331;
app.listen(port, () => {
    logger.info(`Service ${heady-governance} listening on port ${port}`);
});
