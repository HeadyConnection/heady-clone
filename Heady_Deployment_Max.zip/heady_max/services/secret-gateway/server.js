const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('secret-gateway');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'secret-gateway', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'secret-gateway', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3332;
app.listen(port, () => {
    logger.info(`Service ${secret-gateway} listening on port ${port}`);
});
