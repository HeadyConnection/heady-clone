const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-web');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-web', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'heady-web', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3337;
app.listen(port, () => {
    logger.info(`Service ${heady-web} listening on port ${port}`);
});
