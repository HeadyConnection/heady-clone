const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-soul');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-soul', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'heady-soul', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3322;
app.listen(port, () => {
    logger.info(`Service ${heady-soul} listening on port ${port}`);
});
