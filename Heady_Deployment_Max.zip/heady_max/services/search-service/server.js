const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('search-service');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'search-service', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'search-service', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3364;
app.listen(port, () => {
    logger.info(`Service ${search-service} listening on port ${port}`);
});
