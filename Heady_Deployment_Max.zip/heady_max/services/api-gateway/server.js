const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('api-gateway');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'api-gateway', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'api-gateway', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3344;
app.listen(port, () => {
    logger.info(`Service ${api-gateway} listening on port ${port}`);
});
