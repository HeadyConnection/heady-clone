const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('memory-mcp');

// HeadyAutoContext mandatory middleware
app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'memory-mcp', timestamp: Date.now() });
});

app.get('/', (req, res) => {
    res.status(200).json({ service: 'memory-mcp', message: 'Concurrent-equals operational' });
});

const port = process.env.PORT || 3348;
app.listen(port, () => {
    logger.info(`Service ${memory-mcp} listening on port ${port}`);
});
