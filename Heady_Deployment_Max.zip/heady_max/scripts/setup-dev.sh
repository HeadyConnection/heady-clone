#!/bin/bash
echo "Setting up Heady Dev Environment..."
npm install
docker-compose up -d nats postgres redis
echo "Dev environment ready."
