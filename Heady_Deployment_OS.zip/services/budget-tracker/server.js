const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('budget-tracker');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'budget-tracker', timestamp: Date.now() });
});

const port = process.env.PORT || 3358;
app.listen(port, () => {
    logger.info(`Service ${budget-tracker} listening on port ${port}`);
});
