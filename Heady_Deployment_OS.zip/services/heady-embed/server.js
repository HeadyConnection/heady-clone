const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-embed');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-embed', timestamp: Date.now() });
});

const port = process.env.PORT || 3315;
app.listen(port, () => {
    logger.info(`Service ${heady-embed} listening on port ${port}`);
});
