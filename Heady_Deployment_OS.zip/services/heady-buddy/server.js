const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-buddy');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-buddy', timestamp: Date.now() });
});

const port = process.env.PORT || 3338;
app.listen(port, () => {
    logger.info(`Service ${heady-buddy} listening on port ${port}`);
});
