const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('auth-session-server');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'auth-session-server', timestamp: Date.now() });
});

const port = process.env.PORT || 3360;
app.listen(port, () => {
    logger.info(`Service ${auth-session-server} listening on port ${port}`);
});
