const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-bee-factory');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-bee-factory', timestamp: Date.now() });
});

const port = process.env.PORT || 3319;
app.listen(port, () => {
    logger.info(`Service ${heady-bee-factory} listening on port ${port}`);
});
