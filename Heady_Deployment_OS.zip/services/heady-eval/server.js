const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-eval');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-eval', timestamp: Date.now() });
});

const port = process.env.PORT || 3334;
app.listen(port, () => {
    logger.info(`Service ${heady-eval} listening on port ${port}`);
});
