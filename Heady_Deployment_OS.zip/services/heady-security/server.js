const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-security');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-security', timestamp: Date.now() });
});

const port = process.env.PORT || 3330;
app.listen(port, () => {
    logger.info(`Service ${heady-security} listening on port ${port}`);
});
