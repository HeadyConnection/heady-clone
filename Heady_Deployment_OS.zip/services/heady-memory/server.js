const express = require('express');
const { createLogger, CSL_GATES, PHI } = require('@heady/core');
const app = express();
const logger = createLogger('heady-memory');

app.use((req, res, next) => {
    req.headyContext = { phi: PHI, csl: CSL_GATES };
    next();
});

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', service: 'heady-memory', timestamp: Date.now() });
});

const port = process.env.PORT || 3316;
app.listen(port, () => {
    logger.info(`Service ${heady-memory} listening on port ${port}`);
});
