const assert = require('assert');
const { CSL_GATES } = require('@heady/core');
assert.ok(CSL_GATES.include > 0.38 && CSL_GATES.include < 0.39);
console.log('CSL Gates test passed: math constants are phi-scaled.');
